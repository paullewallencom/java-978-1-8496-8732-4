package packt;

public class InvalidParameter extends java.lang.Exception {

    public InvalidParameter() {
        super("Invalid Parameter");
    }
}
