package packt;

public class A {
    public int publicInt;
    private int privateInt;
    protected int protectedInt;
    int defaultInt;	// default (package)
}
